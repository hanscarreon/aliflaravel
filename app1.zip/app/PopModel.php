<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PopModel extends Model
{
    protected $table = 'pop';
    protected $primaryKey = 'popId';
}
