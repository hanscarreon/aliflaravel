<?php

namespace App\Http\Controllers\manage_data;

use App\Http\Controllers\Controller;
use App\Pcvl;
use App\PcvlUpload;
use App\Services\ManageDataService;
use Exception;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ManageDataController extends Controller
{
   
    // DON'T DELETE FOR FUTURE REF.

}
