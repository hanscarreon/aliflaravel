<footer class="footer footer-black  footer-white ">
  <div class="container-fluid">
    <div class="row">
      <nav class="footer-nav">
        <ul>
          <li>
            <a href="https://booking.tourismo.ph/" target="_blank">By: Tourismo</a>
          </li>
        </ul>
      </nav>
      <div class="credits ml-auto">
        <span class="copyright">
          ©
          <script>
            document.write(new Date().getFullYear())
          </script>, Alif Partylist <i class="fa fa-heart heart"></i>
        </span>
      </div>
    </div>
  </div>
</footer>